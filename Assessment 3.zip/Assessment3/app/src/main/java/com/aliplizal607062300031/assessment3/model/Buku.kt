package com.aliplizal607062300031.assessment3.model

data class Buku(
    val id: String,
    val judul: String,
    val kategori: String,
    val status: String,
    val gambar: String,
    val mine: Int?
)

