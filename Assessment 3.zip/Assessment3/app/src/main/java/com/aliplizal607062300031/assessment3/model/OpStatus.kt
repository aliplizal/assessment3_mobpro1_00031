package com.aliplizal607062300031.assessment3.model

data class OpStatus(
    var status: String,
    var message: String?
)