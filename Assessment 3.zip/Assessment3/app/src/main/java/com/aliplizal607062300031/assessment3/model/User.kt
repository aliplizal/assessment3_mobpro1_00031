package com.aliplizal607062300031.assessment3.model

data class User(
    val name: String = "",
    val email: String = "",
    val photoUrl: String = ""
)